#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#define MAX_NAME_LEN 15
#define MAX_NUM_EMPLOYEES 10

/*PUT YOUR STRUCT DEFINITION HERE*/
struct employee {
      char str[MAX_NAME_LEN];
      int id;
      double hours_worked;
      double hourly_rate;
      double net_income;
      double taxes_withheld;
      } list[MAX_NUM_EMPLOYEES], store;

int buildEmployeeList(struct employee list[], struct employee store, char* filename);
int writeSalaryInfoToFile(struct employee list[], int numEmployees, struct employee store, char* filename);
// int writeSalaryInfoToFile(struct employee list[], int numEmployees, char* filename);

#endif //EMPLOYEE_H
