#include <stdio.h>
#include "employee.h"

//Open input file 'filename' and read the following information:
// char* name
// int id
// double hours worked
// double hourly rate
//Create employee structs from this information and store them in the array 'list'
//return the number of employee structs added to list
int buildEmployeeList(struct employee list[], struct employee store, char* filename)
{
    FILE* pFile;
    pFile = fopen(filename, "r");

    if (pFile == NULL)
    {
        printf ("Error opening file\n");
        return 1;
    }
    
    /*
    char namee[50];
    int idd;
    double howo;
    double hora; */
	
    int count = 0;
    /*int i;
    for (i = 0; i < MAX_NUM_EMPLOYEES; i++)
    { */
    while(!feof(pFile) && !ferror(pFile))
    {
      if (fscanf(pFile, "%s ", list[count].str)&& \
          fscanf(pFile, "%d ", &list[count].id)&& \
            fscanf(pFile, "%lf ", &list[count].hours_worked)&& \
              fscanf(pFile, "%lf\n", &list[count].hourly_rate) == 1)
      {
        printf("%s %d %7.2lf %7.2lf\n", list[count].str, list[count].id, list[count].hours_worked, list[count].hourly_rate);
        count++;
      }
      else 
        printf("did not print correctly.");
    } 
    /* } */
    // pFile = fopen("text.txt", "a"); // Appends to the inputfile stream
    // fprintf(pFile, "Total: %d\n", count);
    // printf("Line Count: %d\n", count);
    
    return count;
}

//Open output file 'filename' and write the following information:
// char* name
// double net income
// double taxes withheld
//These items should be separated by commas (no spaces), numbers should have two
//decimal points of precision, and numbers should have no padding (see example output)
int writeSalaryInfoToFile(struct employee list[], int numEmployees, struct employee store, char* filename)
{
    FILE* oFile;
    oFile = fopen(filename, "w");

    if (oFile == NULL)
    {
        printf ("Error opening output file\n");
        return 1;
    }
    int i;
	  for(i = 0; i < numEmployees; i++)
    {
      fprintf(oFile, "%s,%d,%.2lf,%.2lf\n", list[i].str, list[i].id, list[i].net_income, list[i].taxes_withheld);
    }
    return 0;
} 
