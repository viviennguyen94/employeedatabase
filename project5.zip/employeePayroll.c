//This program uses structs to store information from an input text file and project1 calculation to display
//the net income and tax withheld for each employee in an output file. - Vivien Nguyen

#include <stdio.h>
#include <string.h>
#include "employee.h"

#define TAX_RATE  0.15f
#define FULL_TIME 40
#define OVERTIME_RATE_MULTIPLIER 1.5f

void getSalaryInfo(struct employee* emp);
//you probably shouldn't need to alter main...
int main(int argc, char* argv[])
{
	struct employee list[MAX_NUM_EMPLOYEES];
  struct employee temp;

  if(argc < 3)
	{
		printf("Usage: payroll <input filename> <output filename>\n\n");
		return 1;
	} 

	//Build list of employees
	int numEmployees = buildEmployeeList(list, store, argv[1]);
  printf("*Number of employees: %d\n", numEmployees);
   
	//calculate employee income
	int i;
	for(i = 0; i < numEmployees; i++)
	{ 
		getSalaryInfo(&list[i]); //pass pointer to struct
    /*printf("%s %d %7.2lf %7.2lf\n", list[i].str, list[i].id, list[i].hours_worked, list[i].hourly_rate);
		printf("*Net income: %7.2lf\n", list[i].net_income);
		printf("*Taxes withheld: %7.2lf\n", list[i].taxes_withheld); */
	} 
  
  // Alphabetize the employee array
  int k, j;
  for (k = 1; k < numEmployees; k++)
      for (j = 0; j < numEmployees - k; j++) 
      {
         if (strcmp(list[j].str, list[j + 1].str) > 0) 
         {
            temp = list[j];
            list[j] = list[j + 1];
            list[j + 1] = temp;
         }
      }

	//Write employee income to output file
	writeSalaryInfoToFile(list, numEmployees, store, argv[2]);
  printf("Written to output file\n");
	return 0;

}
//calculate net income and taxes withheld - adapt your code from project 1!
//Store the results in the corresponding members of the struct pointed to by 'emp'
void getSalaryInfo(struct employee* emp)
{
  // printf("%s %d %lf %lf\n", (*emp).str, (*emp).id, (*emp).hours_worked, (*emp).hourly_rate);
  double normalIncome;
  double overtimeIncome;
  
	if ((*emp).hours_worked >= FULL_TIME)
	{
		normalIncome = FULL_TIME * (*emp).hourly_rate;
		overtimeIncome = ((*emp).hours_worked - FULL_TIME) * (*emp).hourly_rate * OVERTIME_RATE_MULTIPLIER;
	}
	else
		normalIncome = (*emp).hours_worked * (*emp).hourly_rate;
	(*emp).taxes_withheld = TAX_RATE * (normalIncome + overtimeIncome);
	(*emp).net_income = normalIncome + overtimeIncome - (*emp).taxes_withheld;

}


/*Uncomment and implement with structs for extra credit*/
// int findMax(int a[], int n)
// {
//     int maxIndex = 0;
//     for(int i=1; i<n; i++)
//     {
//         if(a[i] > a[maxIndex])
//             maxIndex = i;
//     }
//     return maxIndex;
// }

// void selectionSort(int a[], int n)
// {
//     if(n > 1)
//     {
//         //Find index of largest element in subarray
//         int maxIndex = findMax(a,n);

//         //Swap this element with the last element in the subarray
//         int temp = a[n-1];
//         a[n-1] = a[maxInd];
//         a[maxInd] = temp;

//         //Recurrsive call to sort next smallest subaray (size n-1)
//         selectionSort(a,n-1);
//     }
// }